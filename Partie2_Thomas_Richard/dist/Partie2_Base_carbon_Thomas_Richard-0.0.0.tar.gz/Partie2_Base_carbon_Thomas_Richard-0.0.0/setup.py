from setuptools import setup, find_packages

setup(
    name="Partie2_Base_carbon_Thomas_Richard",
    version="",
    description="Outil permettant à un restaurateur d'évaluer l'empreinte carbone de son activité",
    author="Thomas Richard",
    packages=find_packages(),
    include_package_data=True)
