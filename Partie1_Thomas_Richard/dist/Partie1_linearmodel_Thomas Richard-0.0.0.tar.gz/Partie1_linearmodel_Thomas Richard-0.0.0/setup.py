from setuptools import setup, find_packages

setup(
    name="Partie1_linearmodel_Thomas Richard",
    version ="",
    description="Projet d'analyse, de visualisation et de régression linéaire sur des émissions de CO2",
    author="Thomas Richard",
    packages=find_packages(),
    include_package_data=True)

