'''Fichier exécutable de la Partie 1'''
from linearmodel import my_statistics
from linearmodel import visualization
from linearmodel import ols